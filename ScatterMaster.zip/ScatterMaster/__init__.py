bl_info = {
    "name": "ScatterMaster",
    "author": "Prajwal Mohite",
    "version": (1, 3),
    "blender": (4, 3, 0),
    "location": "View3D > Sidebar > ScatterMaster",
    "description": "Scatter meshes with offset, jitter, and normal alignment using instancing. Each scatter creates a new collection; Clear removes the latest batch only.",
    "category": "Object",
}

import bpy
import random
import math
from mathutils import Vector, Matrix, geometry as geom

# ------------------------------------------------------------------------
#   Source Item
# ------------------------------------------------------------------------

class ScatterSourceItem(bpy.types.PropertyGroup):
    obj: bpy.props.PointerProperty(name="Object", type=bpy.types.Object)
    weight: bpy.props.FloatProperty(name="Weight", default=1.0, min=0.0)
    scale_mult: bpy.props.FloatProperty(name="Scale Mult", default=1.0, min=0.0)
    rot_mult: bpy.props.FloatProperty(name="Rot Mult", default=1.0, min=0.0)

# ------------------------------------------------------------------------
#   Properties
# ------------------------------------------------------------------------

class ScatterProperties(bpy.types.PropertyGroup):
    count: bpy.props.IntProperty(name="Count", default=100, min=1)

    offset_base: bpy.props.FloatProperty(name="Offset", default=0.1, min=-10.0, max=10.0)
    offset_jitter: bpy.props.FloatProperty(name="Offset Jitter", default=0.05, min=0.0, max=10.0)
    align_with_normal: bpy.props.BoolProperty(name="Align with Mesh Normal", default=False)

    # Scale per-axis
    scale_min_x: bpy.props.FloatProperty(name="Scale Min X", default=0.8)
    scale_max_x: bpy.props.FloatProperty(name="Scale Max X", default=1.2)
    scale_min_y: bpy.props.FloatProperty(name="Scale Min Y", default=0.8)
    scale_max_y: bpy.props.FloatProperty(name="Scale Max Y", default=1.2)
    scale_min_z: bpy.props.FloatProperty(name="Scale Min Z", default=0.8)
    scale_max_z: bpy.props.FloatProperty(name="Scale Max Z", default=1.2)

    # Rotation per-axis
    rot_min_x: bpy.props.FloatProperty(name="Rot Min X", default=-math.pi)
    rot_max_x: bpy.props.FloatProperty(name="Rot Max X", default=math.pi)
    rot_min_y: bpy.props.FloatProperty(name="Rot Min Y", default=-math.pi)
    rot_max_y: bpy.props.FloatProperty(name="Rot Max Y", default=math.pi)
    rot_min_z: bpy.props.FloatProperty(name="Rot Min Z", default=-math.pi)
    rot_max_z: bpy.props.FloatProperty(name="Rot Max Z", default=math.pi)

    sources: bpy.props.CollectionProperty(type=ScatterSourceItem)
    source_index: bpy.props.IntProperty(default=-1)

    # Weight randomization
    weight_min: bpy.props.FloatProperty(name="Min Weight", default=0.1, min=0.0)
    weight_max: bpy.props.FloatProperty(name="Max Weight", default=1.0, min=0.0)

# ------------------------------------------------------------------------
#   Scatter Operator
# ------------------------------------------------------------------------

class SCATTER_OT_basic_scatter(bpy.types.Operator):
    bl_idname = "scatter.basic"
    bl_label = "Scatter Meshes"
    bl_description = "Scatter selected meshes across the active surface with offset and alignment (creates new collection each time)"

    def execute(self, context):
        props = context.scene.scatter_tool
        sources = [s for s in props.sources if s.obj]
        if not sources:
            self.report({'WARNING'}, "No source meshes added")
            return {'CANCELLED'}

        target = context.active_object
        if not target or target.type != 'MESH':
            self.report({'WARNING'}, "Select a mesh to scatter on (as active object)")
            return {'CANCELLED'}

        mesh = target.data
        if not mesh.polygons:
            self.report({'WARNING'}, "Target mesh has no faces")
            return {'CANCELLED'}

        poly_tri_data = []
        for poly in mesh.polygons:
            verts_local = [mesh.vertices[i].co.copy() for i in poly.vertices]
            try:
                tri_indices = geom.tessellate_polygon([verts_local])
            except Exception:
                continue

            tris = []
            areas = []
            for tri in tri_indices:
                v0 = verts_local[tri[0]]
                v1 = verts_local[tri[1]]
                v2 = verts_local[tri[2]]
                tris.append((v0, v1, v2))
                area = 0.5 * ( (v1 - v0).cross(v2 - v0) ).length
                areas.append(area)

            area_sum = sum(areas) if areas else 0.0
            normal_local = poly.normal.copy()
            poly_tri_data.append({
                "tris": tris,
                "areas": areas,
                "area_sum": area_sum,
                "poly_normal": normal_local,
            })

        if not poly_tri_data:
            self.report({'WARNING'}, "No valid faces found for sampling")
            return {'CANCELLED'}

        poly_weights = [p["area_sum"] for p in poly_tri_data]
        total_poly_area = sum(poly_weights)
        if total_poly_area <= 0:
            self.report({'WARNING'}, "Mesh faces have zero area")
            return {'CANCELLED'}
        poly_weights_norm = [w / total_poly_area for w in poly_weights]

        base_name = "Scatter_Instances"
        existing = [c for c in bpy.data.collections if c.name.startswith(base_name)]
        new_index = len(existing) + 1
        coll_name = f"{base_name}_{new_index:03d}"

        scatter_coll = bpy.data.collections.new(coll_name)
        context.scene.collection.children.link(scatter_coll)

        total_source_weight = sum(s.weight for s in sources)
        if total_source_weight <= 0:
            weights = [1.0 / len(sources)] * len(sources)
        else:
            weights = [s.weight / total_source_weight for s in sources]

        for _ in range(props.count):
            src = random.choices(sources, weights=weights, k=1)[0]

            poly_idx = random.choices(range(len(poly_tri_data)), weights=poly_weights_norm, k=1)[0]
            poly_entry = poly_tri_data[poly_idx]

            tris = poly_entry["tris"]
            areas = poly_entry["areas"]
            if not tris or sum(areas) == 0:
                continue
            tri_weights = [a / sum(areas) for a in areas]
            tri_idx = random.choices(range(len(tris)), weights=tri_weights, k=1)[0]
            v0, v1, v2 = tris[tri_idx]

            r1 = math.sqrt(random.random())
            r2 = random.random()
            local_point = (1 - r1) * v0 + r1 * (1 - r2) * v1 + r1 * r2 * v2

            if props.align_with_normal:
                tri_normal_local = (v1 - v0).cross(v2 - v0)
                if tri_normal_local.length > 0.0:
                    tri_normal_local = tri_normal_local.normalized()
                else:
                    tri_normal_local = poly_entry["poly_normal"].normalized()
                world_normal = (target.matrix_world.to_3x3() @ tri_normal_local).normalized()
            else:
                world_normal = None

            offset = props.offset_base + random.uniform(-props.offset_jitter, props.offset_jitter)
            world_point = target.matrix_world @ local_point
            if world_normal:
                world_point = world_point + world_normal * offset
            else:
                poly_norm_world = target.matrix_world.to_3x3() @ poly_entry["poly_normal"]
                poly_norm_world.normalize()
                world_point = world_point + poly_norm_world * offset

            new_obj = bpy.data.objects.new(f"{src.obj.name}_inst", src.obj.data)
            scatter_coll.objects.link(new_obj)
            new_obj.location = world_point

            # Rotation
            rot = [
                random.uniform(props.rot_min_x, props.rot_max_x) * src.rot_mult,
                random.uniform(props.rot_min_y, props.rot_max_y) * src.rot_mult,
                random.uniform(props.rot_min_z, props.rot_max_z) * src.rot_mult,
            ]

            if props.align_with_normal and world_normal:
                up = Vector((0, 0, 1))
                axis = up.cross(world_normal)
                if axis.length > 1e-6:
                    axis.normalize()
                    angle = up.angle(world_normal)
                    align_mat = Matrix.Rotation(angle, 4, axis)
                else:
                    align_mat = Matrix.Identity(4)
                rot_mat = (Matrix.Rotation(rot[2], 4, 'Z') @
                           Matrix.Rotation(rot[1], 4, 'Y') @
                           Matrix.Rotation(rot[0], 4, 'X'))
                new_obj.matrix_world = Matrix.Translation(world_point) @ align_mat @ rot_mat
            else:
                new_obj.rotation_euler = rot

            # Scale
            scale = (
                random.uniform(props.scale_min_x, props.scale_max_x) * src.scale_mult,
                random.uniform(props.scale_min_y, props.scale_max_y) * src.scale_mult,
                random.uniform(props.scale_min_z, props.scale_max_z) * src.scale_mult,
            )
            new_obj.scale = scale

        self.report({'INFO'}, f"Scattered {props.count} instances to '{coll_name}'")
        return {'FINISHED'}

# ------------------------------------------------------------------------
#   Clear Operator (clears only latest collection)
# ------------------------------------------------------------------------

class SCATTER_OT_clear(bpy.types.Operator):
    bl_idname = "scatter.clear"
    bl_label = "Clear Latest Scatter"
    bl_description = "Remove the most recently created Scatter_Instances collection (latest scatter batch only)"

    def execute(self, context):
        scatter_colls = [c for c in bpy.data.collections if c.name.startswith("Scatter_Instances")]
        if not scatter_colls:
            self.report({'WARNING'}, "No scatter collections found")
            return {'CANCELLED'}

        def get_coll_index(name):
            parts = name.split("_")
            try:
                return int(parts[-1])
            except ValueError:
                return 0

        latest_coll = max(scatter_colls, key=lambda c: get_coll_index(c.name))
        coll_name = latest_coll.name

        # Delete all objects inside collection
        for o in list(latest_coll.objects):
            try:
                bpy.data.objects.remove(o, do_unlink=True)
            except RuntimeError:
                pass

        bpy.data.collections.remove(latest_coll)

        self.report({'INFO'}, f"Cleared latest scatter collection '{coll_name}'")
        return {'FINISHED'}

# ------------------------------------------------------------------------
#   Source Management + UI
# ------------------------------------------------------------------------

class SCATTER_OT_add_selected(bpy.types.Operator):
    bl_idname = "scatter.add_selected"
    bl_label = "Add Selected"

    def execute(self, context):
        props = context.scene.scatter_tool
        for obj in context.selected_objects:
            if obj.type == 'MESH' and obj not in [s.obj for s in props.sources]:
                s = props.sources.add()
                s.obj = obj
        return {'FINISHED'}

class SCATTER_OT_clear_sources(bpy.types.Operator):
    bl_idname = "scatter.clear_sources"
    bl_label = "Clear Sources"

    def execute(self, context):
        context.scene.scatter_tool.sources.clear()
        return {'FINISHED'}

class SCATTER_OT_randomize_weights(bpy.types.Operator):
    bl_idname = "scatter.randomize_weights"
    bl_label = "Randomize Weights"

    def execute(self, context):
        props = context.scene.scatter_tool
        for s in props.sources:
            s.weight = random.uniform(props.weight_min, props.weight_max)
        return {'FINISHED'}

class SCATTER_UL_sources(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        if item.obj:
            layout.label(text=item.obj.name, icon='MESH_DATA')
        else:
            layout.label(text="None", icon='ERROR')

class SCATTER_PT_panel(bpy.types.Panel):
    bl_label = "ScatterMaster"
    bl_idname = "SCATTER_PT_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "ScatterMaster"

    def draw(self, context):
        layout = self.layout
        props = context.scene.scatter_tool

        # Sources
        box = layout.box()
        row = box.row()
        row.label(text="Scatter Sources", icon='OUTLINER_OB_MESH')

        box.template_list("SCATTER_UL_sources", "", props, "sources", props, "source_index", rows=3)

        row = box.row(align=True)
        row.operator("scatter.add_selected", icon="ADD", text="Add Selected")
        row.operator("scatter.clear_sources", icon="X", text="Clear All")

        # Selected Source
        if props.sources and 0 <= props.source_index < len(props.sources):
            src = props.sources[props.source_index]
            box.separator()
            box.label(text=f"Selected: {src.obj.name if src.obj else 'None'}", icon="MESH_DATA")
            grid = box.grid_flow(columns=3, align=True)
            grid.prop(src, "weight", text="Weight")
            grid.prop(src, "scale_mult", text="Scale Mult")
            grid.prop(src, "rot_mult", text="Rot Mult")

        # Weight Randomization
        layout.separator()
        box = layout.box()
        box.label(text="Weight Randomization", icon="RNDCURVE")
        row = box.row(align=True)
        row.prop(props, "weight_min", text="Min")
        row.prop(props, "weight_max", text="Max")
        row = box.row(align=True)
        row.operator("scatter.randomize_weights", icon="FILE_REFRESH", text="Randomize")

        # Scatter Settings
        layout.separator()
        box = layout.box()
        box.label(text="Scatter Settings", icon='MOD_PARTICLES')
        col = box.column(align=True)
        col.prop(props, "count", text="Instance Count")
        col.prop(props, "offset_base", text="Base Offset")
        col.prop(props, "offset_jitter", text="Offset Jitter")
        col.separator(factor=1.2)
        col.prop(props, "align_with_normal", text="Align with Surface Normal")

        # Scale
        layout.separator()
        box = layout.box()
        box.label(text="Scale Range", icon="FULLSCREEN_ENTER")
        for axis in ['x', 'y', 'z']:
            row = box.row(align=True)
            row.prop(props, f"scale_min_{axis}", text=f"Min {axis.upper()}")
            row.prop(props, f"scale_max_{axis}", text=f"Max {axis.upper()}")

        # Rotation
        layout.separator()
        box = layout.box()
        box.label(text="Rotation Range (Radians)", icon="DRIVER_ROTATIONAL_DIFFERENCE")
        for axis in ['x', 'y', 'z']:
            row = box.row(align=True)
            row.prop(props, f"rot_min_{axis}", text=f"Min {axis.upper()}")
            row.prop(props, f"rot_max_{axis}", text=f"Max {axis.upper()}")

        # Actions
        layout.separator(factor=1.5)
        row = layout.row(align=True)
        row.scale_y = 1.5
        row.operator("scatter.basic", icon="PARTICLES", text="Scatter Meshes")
        row = layout.row(align=True)
        row.scale_y = 1.5
        row.operator("scatter.clear", icon="TRASH", text="Clear Latest Scatter")

# ------------------------------------------------------------------------
#   Registration
# ------------------------------------------------------------------------

classes = (
    ScatterSourceItem,
    ScatterProperties,
    SCATTER_OT_basic_scatter,
    SCATTER_OT_clear,
    SCATTER_OT_add_selected,
    SCATTER_OT_clear_sources,
    SCATTER_OT_randomize_weights,
    SCATTER_UL_sources,
    SCATTER_PT_panel,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.scatter_tool = bpy.props.PointerProperty(type=ScatterProperties)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.scatter_tool

if __name__ == "__main__":
    register()
